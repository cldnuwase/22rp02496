
package Assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ViewCartServlet1 extends HttpServlet {

   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<html><head><title>View Cart</title></head><body>");
        out.println("<h1>Your Cart</h1>");
        Cookie[] cookies = request.getCookies();
        boolean cartEmpty = true;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("cart".equals(cookie.getName())) {
                    ArrayList<String> cartItems = new ArrayList<>(Arrays.asList(URLDecoder.decode(cookie.getValue(), "UTF-8").split(",")));
                    for (String item : cartItems) {
                        out.println("<p>" + item + "</p>");
                        out.println("<form action='remove-item' method='post'>");
                        out.println("<input type='hidden' name='item' value='" + item + "'>");
                        out.println("<button type='submit'>Remove</button>");
                        out.println("</form>");
                    }
                    cartEmpty = false;
                }
            }
        }
        if (cartEmpty) {
            out.println("<p>Your cart is empty</p>");
        }
        out.println("<a href='index.html'>Continue Shopping</a>");
        out.println("<form action='clear-cart' method='post'>");
        out.println("<button type='submit'>Clear Cart</button>");
        out.println("</form>");
        out.println("</body></html>");
    }
}
}
